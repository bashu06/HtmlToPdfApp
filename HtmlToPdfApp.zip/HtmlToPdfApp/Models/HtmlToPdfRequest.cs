﻿namespace HtmlToPdfApp.Models
{
    public class HtmlToPdfRequest
    {
        public string HtmlContent { get; set; }
    }
}